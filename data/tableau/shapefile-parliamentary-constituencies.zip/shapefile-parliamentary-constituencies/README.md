India - Map of Parliamentary Constituencies, 2019
====

Parliamentary constituency boundaries (Lok Sabha) of India

### india_pc_2019

Parliamentary constituency boundaries Scraped from an Indian Government Website

**License**

The dataset is created by the DataMeet Trust, Bangalore, India, and is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.

### india_pc_2019_simplified

Simplified parliamentary constituency boundaries (<2Mb) for web use, includes corrected and crowdsourced attribute table.

**License**

The dataset is created by Arun Ganesh and is shared under [CC0 1.0 Universal Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/) license.

